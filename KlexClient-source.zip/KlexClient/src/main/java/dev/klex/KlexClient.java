package dev.klex;

import dev.klex.core.Config;
import dev.klex.core.Events;
import dev.klex.core.ModuleManager;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.FMLCommonHandler;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;
import org.lwjgl.opengl.Display;

@Mod(modid = "klexclient", name = "Klex Client", version = "1.0", clientSideOnly = true, acceptedMinecraftVersions = "[1.8.9]")
public class KlexClient {
    @Mod.EventHandler
    public void init(FMLInitializationEvent e) {
        ModuleManager.init();
        Config.load();
        Events ev = new Events();
        MinecraftForge.EVENT_BUS.register(ev);
        FMLCommonHandler.instance().bus().register(ev);
        Runtime.getRuntime().addShutdownHook(new Thread(Config::save));
        Display.setTitle("Klex Client 1.8.9");
    }
}

package dev.klex.gui;

import dev.klex.core.*;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import org.lwjgl.input.Keyboard;

import java.io.IOException;
import java.util.List;

public class HudEditor extends GuiScreen {
    private HudModule drag;
    private int ox, oy;

    @Override public boolean doesGuiPauseGame() { return false; }

    @Override
    public void drawScreen(int mx, int my, float pt) {
        drawRect(0, 0, width, height, 0x99060609);
        Render.rect(width / 2, 0, 1, height, 0x22FFFFFF);
        Render.rect(0, height / 2, width, 1, 0x22FFFFFF);
        ScaledResolution sr = new ScaledResolution(mc);
        for (HudModule h : ModuleManager.huds()) {
            if (!h.enabled) continue;
            h.draw(sr, true);
            Render.outline(h.x - 2, h.y - 2, h.w + 4, h.h + 4, h == drag ? Render.A2 : 0x66FFFFFF);
        }
        String s = "HUD Editor  -  drag elements  |  ESC: back";
        Render.rrect(width / 2 - fontRendererObj.getStringWidth(s) / 2 - 8, 8, fontRendererObj.getStringWidth(s) + 16, 18, 6, 0xDD0E0E15);
        fontRendererObj.drawStringWithShadow(s, width / 2f - fontRendererObj.getStringWidth(s) / 2f, 13, 0xFFFFFFFF);
    }

    @Override
    protected void mouseClicked(int mx, int my, int btn) throws IOException {
        List<HudModule> l = ModuleManager.huds();
        for (int i = l.size() - 1; i >= 0; i--) {
            HudModule h = l.get(i);
            if (h.enabled && mx >= h.x && mx <= h.x + h.w && my >= h.y && my <= h.y + h.h) {
                drag = h; ox = mx - h.x; oy = my - h.y;
                return;
            }
        }
        super.mouseClicked(mx, my, btn);
    }

    @Override
    protected void mouseClickMove(int mx, int my, int btn, long time) {
        if (drag == null) return;
        drag.x = Math.max(0, Math.min(width - drag.w, mx - ox));
        drag.y = Math.max(0, Math.min(height - drag.h, my - oy));
        drag.placed = true;
    }

    @Override protected void mouseReleased(int mx, int my, int state) { drag = null; super.mouseReleased(mx, my, state); }

    @Override
    protected void keyTyped(char c, int key) throws IOException {
        if (key == Keyboard.KEY_ESCAPE) { mc.displayGuiScreen(new ClickGui()); return; }
        super.keyTyped(c, key);
    }

    @Override public void onGuiClosed() { Config.save(); }
}

package dev.klex.gui;

import dev.klex.core.*;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class ClickGui extends GuiScreen {
    private static final int BG = 0xFF0E0E15, SIDE = 0xFF0A0A10, CARD = 0xFF171722, CARD_H = 0xFF1E1E2C, GRAY = 0xFF8A8AA0;

    private static class Hit {
        final int type, x, y, w, h; final Module m; final Setting s; final Category c;
        Hit(int type, int x, int y, int w, int h, Module m, Setting s, Category c) {
            this.type = type; this.x = x; this.y = y; this.w = w; this.h = h; this.m = m; this.s = s; this.c = c;
        }
        boolean in(int mx, int my) { return mx >= x && mx <= x + w && my >= y && my <= y + h; }
    }

    private Category sel = Category.HUD;
    private Module expanded;
    private float scroll, target, maxScroll;
    private long open;
    private Hit drag;
    private int clipX, clipY, clipW, clipH;
    private final List<Hit> hits = new ArrayList<>();

    @Override public void initGui() { open = System.currentTimeMillis(); }
    @Override public boolean doesGuiPauseGame() { return false; }

    @Override
    public void drawScreen(int mx, int my, float pt) {
        hits.clear();
        FontRenderer f = fontRendererObj;
        float t = Math.min(1f, (System.currentTimeMillis() - open) / 220f);
        float e = 1f - (1f - t) * (1f - t) * (1f - t);
        drawRect(0, 0, width, height, ((int) (150 * e) << 24) | 0x050508);

        int pw = Math.min(480, width - 16), ph = Math.min(290, height - 16);
        int px = (width - pw) / 2, py = (height - ph) / 2 + (int) ((1f - e) * 16);
        Render.rrect(px - 1, py - 1, pw + 2, ph + 2, 9, 0xFF2B2145);
        Render.rrect(px, py, pw, ph, 8, BG);
        int sw = 98;
        Render.rrect(px, py, sw, ph, 8, SIDE);
        Render.rect(px + sw - 10, py, 10, ph, SIDE);

        // logo
        Render.gradText("KLEX", px + 16, py + 14, 2.2f);
        f.drawStringWithShadow("C L I E N T", px + 17, py + 36, GRAY);

        // categories
        Category[] cats = Category.values();
        for (int i = 0; i < cats.length; i++) {
            Category c = cats[i];
            int by = py + 62 + i * 26;
            boolean hv = mx >= px + 8 && mx <= px + sw - 8 && my >= by && my <= by + 22;
            if (c == sel) { Render.rrect(px + 8, by, sw - 16, 22, 6, 0x448B5CF6); Render.rrect(px + 8, by + 5, 2, 12, 1, Render.A1); }
            else if (hv) Render.rrect(px + 8, by, sw - 16, 22, 6, 0x22FFFFFF);
            f.drawStringWithShadow(c.label, px + 18, by + 7, c == sel ? 0xFFFFFFFF : GRAY);
            String n = String.valueOf(ModuleManager.of(c).size());
            f.drawStringWithShadow(n, px + sw - 14 - f.getStringWidth(n), by + 7, GRAY);
            hits.add(new Hit(0, px + 8, by, sw - 16, 22, null, null, c));
        }

        // HUD editor button
        int bx = px + 8, by = py + ph - 36, bw = sw - 16;
        boolean bh = mx >= bx && mx <= bx + bw && my >= by && my <= by + 22;
        Render.rrect(bx, by, bw, 22, 6, bh ? Render.A2 : Render.A1);
        f.drawStringWithShadow("HUD Editor", bx + (bw - f.getStringWidth("HUD Editor")) / 2f, by + 7, 0xFFFFFFFF);
        hits.add(new Hit(4, bx, by, bw, 22, null, null, null));

        // header
        int cx = px + sw + 14, cw = pw - sw - 28;
        Render.gradText(sel.label.toUpperCase(), cx, py + 12, 1.6f);
        f.drawStringWithShadow(ModuleManager.of(sel).size() + " modules  |  right-click for settings  |  RSHIFT to close", cx, py + 30, GRAY);

        // content
        clipX = cx - 2; clipY = py + 46; clipW = cw + 4; clipH = ph - 56;
        target = Math.max(0f, Math.min(target, maxScroll));
        scroll += (target - scroll) * 0.35f;

        ScaledResolution sr = new ScaledResolution(mc);
        int sf = sr.getScaleFactor();
        GL11.glEnable(GL11.GL_SCISSOR_TEST);
        GL11.glScissor(clipX * sf, mc.displayHeight - (clipY + clipH) * sf, clipW * sf, clipH * sf);

        int y = clipY - (int) scroll;
        for (Module m : ModuleManager.of(sel)) {
            boolean exp = expanded == m && !m.settings.isEmpty();
            int extra = exp ? m.settings.size() * 20 + 4 : 0;
            int h = 34 + extra;
            m.anim += ((m.enabled ? 1f : 0f) - m.anim) * 0.25f;
            if (y + h >= clipY && y <= clipY + clipH) {
                boolean hv = mx >= cx && mx <= cx + cw && my >= Math.max(y, clipY) && my <= Math.min(y + 34, clipY + clipH);
                Render.rrect(cx, y, cw, h, 7, hv ? CARD_H : CARD);
                if (m.enabled) Render.rrect(cx, y + 9, 3, 16, 1, Render.A1);
                f.drawStringWithShadow(m.name, cx + 12, y + 8, 0xFFFFFFFF);
                f.drawStringWithShadow(m.desc, cx + 12, y + 20, GRAY);
                if (!m.settings.isEmpty()) f.drawStringWithShadow("...", cx + cw - 54, y + 11, GRAY);
                Render.toggle(cx + cw - 34, y + 11, m.anim);
                hits.add(new Hit(1, cx, y, cw, 34, m, null, null));
                if (exp) {
                    Render.rect(cx + 10, y + 34, cw - 20, 1, 0xFF2A2A38);
                    for (int i = 0; i < m.settings.size(); i++) {
                        Setting s = m.settings.get(i);
                        int sy = y + 36 + i * 20;
                        if (s.isBool) {
                            f.drawStringWithShadow(s.name, cx + 14, sy + 5, 0xFFD0D0E0);
                            Render.toggle(cx + cw - 34, sy + 3, s.b ? 1f : 0f);
                            hits.add(new Hit(2, cx, sy, cw, 20, m, s, null));
                        } else {
                            int tx = cx + cw - 134, tw = 112;
                            String val = s.max - s.min > 20 ? String.valueOf((int) s.v) : String.format("%.1f", s.v);
                            f.drawStringWithShadow(s.name + " \u00a77" + val, cx + 14, sy + 5, 0xFFD0D0E0);
                            Render.rrect(tx, sy + 8, tw, 4, 2, 0xFF2A2A38);
                            int fw = (int) (tw * (s.v - s.min) / (s.max - s.min));
                            Render.rrect(tx, sy + 8, Math.max(4, fw), 4, 2, Render.A1);
                            Render.rrect(tx + fw - 3, sy + 6, 7, 8, 3, 0xFFFFFFFF);
                            hits.add(new Hit(3, tx, sy, tw, 20, m, s, null));
                        }
                    }
                }
            }
            y += h + 6;
        }
        maxScroll = Math.max(0, (y + (int) scroll - clipY) - clipH);
        GL11.glDisable(GL11.GL_SCISSOR_TEST);

        // scrollbar
        if (maxScroll > 0) {
            int th = Math.max(20, (int) (clipH * (clipH / (clipH + maxScroll))));
            int ty = clipY + (int) ((clipH - th) * (scroll / maxScroll));
            Render.rrect(px + pw - 7, ty, 3, th, 1, 0xFF3A3A50);
        }
        if (drag != null) slide(drag, mx);
    }

    private void slide(Hit h, int mx) {
        double t = Math.max(0, Math.min(1, (mx - h.x) / (double) h.w));
        double v = h.s.min + t * (h.s.max - h.s.min);
        h.s.v = (h.s.max - h.s.min > 20) ? Math.round(v) : Math.round(v * 10) / 10.0;
    }

    @Override
    protected void mouseClicked(int mx, int my, int btn) throws IOException {
        for (int i = hits.size() - 1; i >= 0; i--) {
            Hit h = hits.get(i);
            if (!h.in(mx, my)) continue;
            if (h.type >= 1 && h.type <= 3 && (my < clipY || my > clipY + clipH)) continue;
            switch (h.type) {
                case 0: sel = h.c; scroll = target = 0; expanded = null; break;
                case 1:
                    if (btn == 0) h.m.toggle();
                    else if (btn == 1 && !h.m.settings.isEmpty()) expanded = expanded == h.m ? null : h.m;
                    break;
                case 2: h.s.b = !h.s.b; break;
                case 3: drag = h; slide(h, mx); break;
                case 4: mc.displayGuiScreen(new HudEditor()); break;
            }
            return;
        }
        super.mouseClicked(mx, my, btn);
    }

    @Override protected void mouseReleased(int mx, int my, int state) { drag = null; super.mouseReleased(mx, my, state); }

    @Override
    public void handleMouseInput() throws IOException {
        super.handleMouseInput();
        int d = Mouse.getEventDWheel();
        if (d != 0) target -= Math.signum(d) * 30f;
    }

    @Override
    protected void keyTyped(char c, int key) throws IOException {
        if (key == Keyboard.KEY_RSHIFT) { mc.displayGuiScreen(null); return; }
        super.keyTyped(c, key);
    }

    @Override public void onGuiClosed() { Config.save(); }
}

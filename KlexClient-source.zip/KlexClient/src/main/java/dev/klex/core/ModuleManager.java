package dev.klex.core;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.RenderHelper;
import net.minecraft.client.resources.I18n;
import net.minecraft.client.settings.GameSettings;
import net.minecraft.entity.EntityLivingBase;
import net.minecraft.init.Items;
import net.minecraft.item.ItemPotion;
import net.minecraft.item.ItemSoup;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;
import net.minecraft.potion.PotionEffect;
import net.minecraft.util.BlockPos;
import net.minecraft.util.ChatComponentText;
import net.minecraft.util.EnumFacing;
import net.minecraft.util.MovingObjectPosition;
import net.minecraftforge.client.event.ClientChatReceivedEvent;
import net.minecraftforge.client.event.FOVUpdateEvent;
import net.minecraftforge.client.event.RenderBlockOverlayEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import org.lwjgl.input.Keyboard;
import org.lwjgl.input.Mouse;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.function.Predicate;
import java.util.function.Supplier;

public class ModuleManager {
    public static final List<Module> all = new ArrayList<>();
    static final Minecraft mc = Minecraft.getMinecraft();
    private static int idx;

    public static List<Module> of(Category c) {
        List<Module> l = new ArrayList<>();
        for (Module m : all) if (m.cat == c) l.add(m);
        return l;
    }

    public static List<HudModule> huds() {
        List<HudModule> l = new ArrayList<>();
        for (Module m : all) if (m instanceof HudModule) l.add((HudModule) m);
        return l;
    }

    private static <T extends Module> T reg(T m) { all.add(m); return m; }

    private static HudModule hud(String n, String d, boolean on, Supplier<String> s) {
        HudModule m = new HudModule(n, d, s);
        m.x = 6 + (idx / 9) * 120;
        m.y = 26 + (idx % 9) * 19;
        m.placed = true;
        idx++;
        m.enabled = on;
        return reg(m);
    }

    private static int count(Predicate<ItemStack> p) {
        int n = 0;
        for (ItemStack s : mc.thePlayer.inventory.mainInventory) if (s != null && p.test(s)) n += s.stackSize;
        return n;
    }

    public static void init() {
        // ===================== HUD =====================
        HudModule wm = new HudModule("Watermark", "Klex Client logo") {
            @Override public void defaultPos(ScaledResolution sr) { x = 6; y = 6; }
            @Override public void render(ScaledResolution sr, boolean pv) {
                FontRenderer f = mc.fontRendererObj;
                String s = "KLEX CLIENT", v = " 1.8.9";
                w = f.getStringWidth(s) + f.getStringWidth(v) + 18;
                h = 18;
                bg(w, h);
                Render.gradText(s, x + 9, y + 5, 1f);
                f.drawStringWithShadow(v, x + 9 + f.getStringWidth(s), y + 5, 0xFF8A8AA0);
            }
        };
        wm.enabled = true;
        reg(wm);

        hud("FPS", "Frames per second", true, () -> net.minecraft.client.Minecraft.getDebugFPS() + " FPS");
        hud("CPS", "Clicks per second (LMB | RMB)", true, () -> Stats.cps(0) + " | " + Stats.cps(1) + " CPS");
        hud("Ping", "Server latency", true, () -> {
            net.minecraft.client.network.NetworkPlayerInfo i = mc.getNetHandler() == null ? null : mc.getNetHandler().getPlayerInfo(mc.thePlayer.getUniqueID());
            return (i == null ? 0 : i.getResponseTime()) + " ms";
        });
        hud("Coordinates", "XYZ position", true, () ->
                String.format("XYZ: %d %d %d", (int) Math.floor(mc.thePlayer.posX), (int) Math.floor(mc.thePlayer.posY), (int) Math.floor(mc.thePlayer.posZ)));
        hud("Direction", "Facing direction", false, () -> {
            String d = EnumFacing.fromAngle(mc.thePlayer.rotationYaw).getName();
            return Character.toUpperCase(d.charAt(0)) + d.substring(1);
        });
        hud("Biome", "Current biome", false, () -> mc.theWorld.getBiomeGenForCoords(new BlockPos(mc.thePlayer)).biomeName);
        hud("Clock", "Real-time clock", false, () -> new SimpleDateFormat("HH:mm:ss").format(new Date()));
        hud("Speed", "Speed in blocks/second", false, () -> String.format("%.2f b/s", Stats.speed));
        hud("Memory", "RAM usage", false, () -> {
            Runtime r = Runtime.getRuntime();
            return ((r.totalMemory() - r.freeMemory()) >> 20) + "/" + (r.maxMemory() >> 20) + " MB";
        });
        hud("Server IP", "Current server address", false, () ->
                mc.getCurrentServerData() == null ? "Singleplayer" : mc.getCurrentServerData().serverIP);
        hud("Day Counter", "World day", false, () -> "Day " + (mc.theWorld.getWorldTime() / 24000L));
        hud("Light Level", "Light at your position", false, () -> "Light: " + mc.theWorld.getLightFromNeighbors(new BlockPos(mc.thePlayer)));
        hud("Player Count", "Players online", false, () ->
                (mc.getNetHandler() == null ? mc.theWorld.playerEntities.size() : mc.getNetHandler().getPlayerInfoMap().size()) + " players");
        hud("Health", "Your health", false, () -> (int) Math.ceil(mc.thePlayer.getHealth()) + " HP");
        hud("Hunger", "Your food level", false, () -> mc.thePlayer.getFoodStats().getFoodLevel() + " Food");
        hud("Combo Counter", "Hits in a row", false, () -> Stats.combo + " Combo");
        hud("Pot Counter", "Splash potions in inventory", false, () ->
                count(s -> s.getItem() instanceof ItemPotion && ItemPotion.isSplash(s.getMetadata())) + " Pots");
        hud("Soup Counter", "Soups in inventory", false, () -> count(s -> s.getItem() instanceof ItemSoup) + " Soups");
        hud("Arrow Counter", "Arrows in inventory", false, () -> count(s -> s.getItem() == Items.arrow) + " Arrows");
        hud("Held Item", "Held item & durability", false, () -> {
            ItemStack s = mc.thePlayer.getHeldItem();
            if (s == null) return "Empty hand";
            return s.getDisplayName() + (s.getMaxDamage() > 0 ? " " + (s.getMaxDamage() - s.getItemDamage()) + "/" + s.getMaxDamage() : s.stackSize > 1 ? " x" + s.stackSize : "");
        });
        final double[] lastReach = {0};
        final boolean[] hasReach = {false};
        hud("Reach Display", "Distance to the entity you aim at", false, () -> {
            MovingObjectPosition o = mc.objectMouseOver;
            if (o != null && o.typeOfHit == MovingObjectPosition.MovingObjectType.ENTITY && o.hitVec != null) {
                lastReach[0] = mc.thePlayer.getPositionEyes(1f).distanceTo(o.hitVec);
                hasReach[0] = true;
            }
            return hasReach[0] ? String.format("%.2f blocks", lastReach[0]) : "- blocks";
        });

        HudModule armor = new HudModule("Armor Status", "Armor & held item durability") {
            @Override public void defaultPos(ScaledResolution sr) { x = sr.getScaledWidth() - 82; y = sr.getScaledHeight() - 110; }
            @Override public void render(ScaledResolution sr, boolean pv) {
                List<ItemStack> l = new ArrayList<>();
                ItemStack[] a = mc.thePlayer.inventory.armorInventory;
                for (int i = 3; i >= 0; i--) if (a[i] != null) l.add(a[i]);
                if (mc.thePlayer.getHeldItem() != null) l.add(mc.thePlayer.getHeldItem());
                if (l.isEmpty()) { lines(new ArrayList<String>(), pv); return; }
                FontRenderer f = mc.fontRendererObj;
                w = 76; h = l.size() * 18 + 4;
                bg(w, h);
                int yy = y + 2;
                for (ItemStack s : l) {
                    GlStateManager.enableRescaleNormal();
                    RenderHelper.enableGUIStandardItemLighting();
                    mc.getRenderItem().renderItemAndEffectIntoGUI(s, x + 8, yy);
                    RenderHelper.disableStandardItemLighting();
                    GlStateManager.disableRescaleNormal();
                    GlStateManager.disableLighting();
                    GlStateManager.enableBlend();
                    GlStateManager.color(1f, 1f, 1f, 1f);
                    String t = "";
                    int col = 0xFFFFFFFF;
                    if (s.getMaxDamage() > 0) {
                        int left = s.getMaxDamage() - s.getItemDamage();
                        float pct = left / (float) s.getMaxDamage();
                        t = String.valueOf(left);
                        col = pct > 0.6f ? 0xFF55FF55 : pct > 0.3f ? 0xFFFFFF55 : 0xFFFF5555;
                    } else if (s.stackSize > 1) t = "x" + s.stackSize;
                    f.drawStringWithShadow(t, x + 28, yy + 5, col);
                    yy += 18;
                }
            }
        };
        reg(armor);

        HudModule potions = new HudModule("Potion Effects", "Active potion effects") {
            @Override public void defaultPos(ScaledResolution sr) { x = sr.getScaledWidth() - 110; y = 6; }
            @Override public void render(ScaledResolution sr, boolean pv) {
                List<String> ls = new ArrayList<>();
                Collection<PotionEffect> fx = mc.thePlayer.getActivePotionEffects();
                for (PotionEffect e : fx) {
                    Potion p = Potion.potionTypes[e.getPotionID()];
                    if (p == null) continue;
                    ls.add(I18n.format(p.getName()) + " " + (e.getAmplifier() + 1) + " \u00a77" + Potion.getDurationString(e));
                }
                lines(ls, pv);
            }
        };
        potions.enabled = true;
        reg(potions);

        final float[] an = new float[7];
        HudModule keys = new HudModule("Keystrokes", "WASD, mouse buttons, space & CPS") {
            @Override public void defaultPos(ScaledResolution sr) { x = 8; y = sr.getScaledHeight() - 100; }
            private void key(int i, int kx, int ky, int kw, int kh, String lbl, boolean down, String sub) {
                an[i] += ((down ? 1f : 0f) - an[i]) * 0.3f;
                Render.rrect(kx, ky, kw, kh, 4, Render.lerp(0x99101018, 0xDD8B5CF6, an[i]));
                FontRenderer f = mc.fontRendererObj;
                f.drawStringWithShadow(lbl, kx + (kw - f.getStringWidth(lbl)) / 2f, ky + (sub == null ? (kh - 8) / 2f : 4), 0xFFFFFFFF);
                if (sub != null) f.drawStringWithShadow(sub, kx + (kw - f.getStringWidth(sub)) / 2f, ky + kh - 11, 0xFFB0B0C0);
            }
            @Override public void render(ScaledResolution sr, boolean pv) {
                w = 70; h = 88;
                GameSettings g = mc.gameSettings;
                key(0, x + 24, y, 22, 22, "W", g.keyBindForward.isKeyDown(), null);
                key(1, x, y + 24, 22, 22, "A", g.keyBindLeft.isKeyDown(), null);
                key(2, x + 24, y + 24, 22, 22, "S", g.keyBindBack.isKeyDown(), null);
                key(3, x + 48, y + 24, 22, 22, "D", g.keyBindRight.isKeyDown(), null);
                key(4, x, y + 48, 34, 26, "LMB", Mouse.isButtonDown(0), Stats.cps(0) + " CPS");
                key(5, x + 36, y + 48, 34, 26, "RMB", Mouse.isButtonDown(1), Stats.cps(1) + " CPS");
                key(6, x, y + 76, 70, 12, "", Keyboard.isKeyDown(g.keyBindJump.getKeyCode()), null);
                Render.rect(x + 22, y + 81, 26, 2, 0xFFFFFFFF);
            }
        };
        keys.enabled = true;
        reg(keys);

        HudModule target = new HudModule("Target HUD", "Shows the entity you're looking at") {
            EntityLivingBase tgt; long seen; float hp = 20f;
            @Override public void defaultPos(ScaledResolution sr) { x = sr.getScaledWidth() / 2 + 20; y = sr.getScaledHeight() / 2 + 20; }
            @Override public void render(ScaledResolution sr, boolean pv) {
                MovingObjectPosition o = mc.objectMouseOver;
                if (o != null && o.typeOfHit == MovingObjectPosition.MovingObjectType.ENTITY && o.entityHit instanceof EntityLivingBase) {
                    tgt = (EntityLivingBase) o.entityHit;
                    seen = System.currentTimeMillis();
                }
                boolean show = tgt != null && !tgt.isDead && System.currentTimeMillis() - seen < 2000;
                if (!show && !pv) return;
                FontRenderer f = mc.fontRendererObj;
                w = 120; h = 34;
                bg(w, h);
                float cur = show ? tgt.getHealth() : 20f, max = show ? Math.max(1f, tgt.getMaxHealth()) : 20f;
                f.drawStringWithShadow(show ? tgt.getName() : "Target", x + 9, y + 5, 0xFFFFFFFF);
                String hs = String.format("%.1f HP", cur);
                f.drawStringWithShadow(hs, x + w - 7 - f.getStringWidth(hs), y + 5, 0xFF8A8AA0);
                hp += (cur - hp) * 0.2f;
                Render.rrect(x + 9, y + 20, w - 18, 6, 3, 0xFF23232E);
                int fw = (int) ((w - 18) * Math.max(0f, Math.min(1f, hp / max)));
                if (fw > 0) Render.gradH(x + 9, y + 20, fw, 6, Render.A1, Render.A2);
            }
        };
        reg(target);

        // ===================== VISUAL =====================
        reg(new Module("Crosshair", "Custom crosshair", Category.VISUAL) {
            { add(Setting.num("Size", 5, 1, 15)); add(Setting.num("Gap", 3, 0, 10)); add(Setting.num("Thickness", 1, 1, 4));
              add(Setting.bool("Dot", false)); add(Setting.bool("Dynamic Color", true)); add(Setting.bool("Outline", true)); }
            @Override public void onOverlayPre(RenderGameOverlayEvent.Pre e) {
                if (e.type != RenderGameOverlayEvent.ElementType.CROSSHAIRS) return;
                e.setCanceled(true);
                int cx = e.resolution.getScaledWidth() / 2, cy = e.resolution.getScaledHeight() / 2;
                int s = (int) num("Size"), g = (int) num("Gap"), t = (int) num("Thickness");
                MovingObjectPosition o = mc.objectMouseOver;
                boolean on = o != null && o.typeOfHit == MovingObjectPosition.MovingObjectType.ENTITY;
                int col = bool("Dynamic Color") && on ? 0xFFFF4D6D : 0xFFFFFFFF;
                int[][] r = {{cx - g - s, cy - t / 2, s, t}, {cx + g, cy - t / 2, s, t}, {cx - t / 2, cy - g - s, t, s}, {cx - t / 2, cy + g, t, s}};
                if (bool("Outline")) {
                    for (int[] a : r) Render.rect(a[0] - 1, a[1] - 1, a[2] + 2, a[3] + 2, 0xFF000000);
                    if (bool("Dot")) Render.rect(cx - t / 2 - 1, cy - t / 2 - 1, t + 2, t + 2, 0xFF000000);
                }
                for (int[] a : r) Render.rect(a[0], a[1], a[2], a[3], col);
                if (bool("Dot")) Render.rect(cx - t / 2, cy - t / 2, t, t, col);
            }
        });
        reg(new Module("Fullbright", "Maximum brightness", Category.VISUAL) {
            float prev = 1f;
            @Override public void onEnable() { prev = mc.gameSettings.gammaSetting > 1f ? 1f : mc.gameSettings.gammaSetting; mc.gameSettings.gammaSetting = 100f; }
            @Override public void onDisable() { mc.gameSettings.gammaSetting = prev; }
            @Override public void onTick() { mc.gameSettings.gammaSetting = 100f; }
        });
        reg(new Module("Zoom", "Hold C to zoom in", Category.VISUAL) {
            { add(Setting.num("Zoom Factor", 4, 1.5, 10)); }
            @Override public void onFov(FOVUpdateEvent e) {
                if (Keyboard.isKeyDown(Keyboard.KEY_C) && mc.currentScreen == null) e.newfov /= (float) num("Zoom Factor");
            }
        });
        reg(new Module("No Hurt Cam", "Removes screen shake when hit", Category.VISUAL) {
            @Override public void onTick() { mc.thePlayer.hurtTime = 0; }
        });
        reg(new Module("No Fire", "Hides the fire overlay", Category.VISUAL) {
            @Override public void onBlockOverlay(RenderBlockOverlayEvent e) {
                if (e.overlayType == RenderBlockOverlayEvent.OverlayType.FIRE) e.setCanceled(true);
            }
        });
        reg(new Module("No Portal Overlay", "Hides the nether portal effect", Category.VISUAL) {
            @Override public void onOverlayPre(RenderGameOverlayEvent.Pre e) { if (e.type == RenderGameOverlayEvent.ElementType.PORTAL) e.setCanceled(true); }
        });
        reg(new Module("No Pumpkin Blur", "Hides the pumpkin overlay", Category.VISUAL) {
            @Override public void onOverlayPre(RenderGameOverlayEvent.Pre e) { if (e.type == RenderGameOverlayEvent.ElementType.HELMET) e.setCanceled(true); }
        });
        reg(new Module("No Boss Bar", "Hides the boss health bar", Category.VISUAL) {
            @Override public void onOverlayPre(RenderGameOverlayEvent.Pre e) { if (e.type == RenderGameOverlayEvent.ElementType.BOSSHEALTH) e.setCanceled(true); }
        });
        reg(new Module("Clear Weather", "Removes rain & thunder (client-side)", Category.VISUAL) {
            @Override public void onTick() { mc.theWorld.setRainStrength(0f); mc.theWorld.setThunderStrength(0f); }
        });
        reg(new Module("Time Changer", "Set the time of day (client-side)", Category.VISUAL) {
            { add(Setting.num("Time", 6000, 0, 24000)); }
            @Override public void onTick() { mc.theWorld.setWorldTime((long) num("Time")); }
        });
        reg(new Module("Static FOV", "No FOV change from sprinting/speed", Category.VISUAL) {
            @Override public void onFov(FOVUpdateEvent e) { if (!(Keyboard.isKeyDown(Keyboard.KEY_C) && mc.currentScreen == null)) e.newfov = 1f; }
        });
        reg(new Module("No View Bobbing", "Disables camera bobbing", Category.VISUAL) {
            boolean prev = true;
            @Override public void onEnable() { prev = mc.gameSettings.viewBobbing; mc.gameSettings.viewBobbing = false; }
            @Override public void onDisable() { mc.gameSettings.viewBobbing = prev; }
        });
        reg(new Module("FPS Boost", "Lowers graphics for more FPS", Category.VISUAL) {
            boolean shadows, fancy; int particles, ao;
            @Override public void onEnable() {
                GameSettings g = mc.gameSettings;
                shadows = g.entityShadows; fancy = g.fancyGraphics; particles = g.particleSetting; ao = g.ambientOcclusion;
                g.entityShadows = false; g.fancyGraphics = false; g.particleSetting = 2; g.ambientOcclusion = 0;
            }
            @Override public void onDisable() {
                GameSettings g = mc.gameSettings;
                g.entityShadows = shadows; g.fancyGraphics = fancy; g.particleSetting = particles; g.ambientOcclusion = ao;
            }
        });

        // ===================== UTILITY =====================
        Module sprint = new Module("Toggle Sprint", "Always sprint while moving forward", Category.UTILITY) {
            @Override public void onTick() {
                if (mc.currentScreen == null && mc.thePlayer.movementInput.moveForward > 0 && !mc.thePlayer.isSneaking()
                        && !mc.thePlayer.isUsingItem() && !mc.thePlayer.isCollidedHorizontally && mc.thePlayer.getFoodStats().getFoodLevel() > 6)
                    mc.thePlayer.setSprinting(true);
            }
        };
        sprint.enabled = true;
        reg(sprint);
        reg(new Module("Toggle Sneak", "Hold sneak automatically", Category.UTILITY) {
            @Override public void onTick() {
                if (mc.currentScreen == null) net.minecraft.client.settings.KeyBinding.setKeyBindState(mc.gameSettings.keyBindSneak.getKeyCode(), true);
            }
            @Override public void onDisable() {
                net.minecraft.client.settings.KeyBinding.setKeyBindState(mc.gameSettings.keyBindSneak.getKeyCode(), false);
            }
        });
        reg(new Module("Chat Timestamps", "Adds [HH:mm] before chat messages", Category.UTILITY) {
            @Override public void onChat(ClientChatReceivedEvent e) {
                if (e.type == 2) return;
                e.message = new ChatComponentText("\u00a78[\u00a7d" + new SimpleDateFormat("HH:mm").format(new Date()) + "\u00a78] \u00a7r").appendSibling(e.message);
            }
        });
    }
}

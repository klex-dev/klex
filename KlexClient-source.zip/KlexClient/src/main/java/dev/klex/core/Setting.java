package dev.klex.core;

public class Setting {
    public final String name;
    public final boolean isBool;
    public boolean b;
    public double v, min, max;

    private Setting(String n, boolean isBool) { this.name = n; this.isBool = isBool; }

    public static Setting bool(String n, boolean def) {
        Setting s = new Setting(n, true);
        s.b = def;
        return s;
    }

    public static Setting num(String n, double def, double min, double max) {
        Setting s = new Setting(n, false);
        s.v = def; s.min = min; s.max = max;
        return s;
    }
}

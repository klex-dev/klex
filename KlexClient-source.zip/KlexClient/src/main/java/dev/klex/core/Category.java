package dev.klex.core;

public enum Category {
    HUD("HUD"), VISUAL("Visual"), UTILITY("Utility");
    public final String label;
    Category(String l) { label = l; }
}

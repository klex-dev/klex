package dev.klex.core;

import net.minecraft.client.Minecraft;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Properties;

public class Config {
    private static File file() {
        return new File(Minecraft.getMinecraft().mcDataDir, "config/klex.properties");
    }

    public static void save() {
        try {
            Properties p = new Properties();
            for (Module m : ModuleManager.all) {
                p.setProperty(m.name + ".on", String.valueOf(m.enabled));
                for (Setting s : m.settings)
                    p.setProperty(m.name + "." + s.name, s.isBool ? String.valueOf(s.b) : String.valueOf(s.v));
                if (m instanceof HudModule) {
                    p.setProperty(m.name + ".x", String.valueOf(((HudModule) m).x));
                    p.setProperty(m.name + ".y", String.valueOf(((HudModule) m).y));
                }
            }
            File f = file();
            f.getParentFile().mkdirs();
            try (FileOutputStream o = new FileOutputStream(f)) { p.store(o, "Klex Client"); }
        } catch (Exception ignored) {}
    }

    public static void load() {
        File f = file();
        if (!f.exists()) return;
        try (FileInputStream in = new FileInputStream(f)) {
            Properties p = new Properties();
            p.load(in);
            for (Module m : ModuleManager.all) {
                for (Setting s : m.settings) {
                    String v = p.getProperty(m.name + "." + s.name);
                    if (v == null) continue;
                    if (s.isBool) s.b = Boolean.parseBoolean(v);
                    else s.v = Math.max(s.min, Math.min(s.max, Double.parseDouble(v)));
                }
                if (m instanceof HudModule && p.getProperty(m.name + ".x") != null) {
                    HudModule h = (HudModule) m;
                    h.x = Integer.parseInt(p.getProperty(m.name + ".x"));
                    h.y = Integer.parseInt(p.getProperty(m.name + ".y"));
                    h.placed = true;
                }
                String on = p.getProperty(m.name + ".on");
                if (on != null) m.setEnabled(Boolean.parseBoolean(on));
            }
        } catch (Exception ignored) {}
    }
}

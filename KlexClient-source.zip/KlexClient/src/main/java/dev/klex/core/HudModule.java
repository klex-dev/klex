package dev.klex.core;

import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.renderer.GlStateManager;

import java.util.Collections;
import java.util.List;
import java.util.function.Supplier;

public class HudModule extends Module {
    public int x, y, w = 60, h = 16;
    public boolean placed;
    private final Supplier<String> text;

    public HudModule(String n, String d, Supplier<String> text) {
        super(n, d, Category.HUD);
        this.text = text;
        add(Setting.bool("Background", true));
    }

    public HudModule(String n, String d) { this(n, d, null); }

    public void defaultPos(ScaledResolution sr) {}

    public final void draw(ScaledResolution sr, boolean pv) {
        if (!placed) { defaultPos(sr); placed = true; }
        GlStateManager.color(1f, 1f, 1f, 1f);
        GlStateManager.enableTexture2D();
        render(sr, pv);
        GlStateManager.color(1f, 1f, 1f, 1f);
    }

    public void render(ScaledResolution sr, boolean pv) {
        String s = text == null ? null : text.get();
        if (s == null) return;
        lines(Collections.singletonList(s), pv);
    }

    protected void bg(int w, int h) {
        if (!bool("Background")) return;
        Render.rrect(x, y, w, h, 4, 0x99101018);
        Render.rrect(x + 3, y + 4, 2, h - 8, 1, Render.A1);
    }

    protected void lines(List<String> ls, boolean pv) {
        if (ls.isEmpty()) {
            if (!pv) return;
            ls = Collections.singletonList("\u00a77" + name);
        }
        FontRenderer f = mc.fontRendererObj;
        int mw = 0;
        for (String s : ls) mw = Math.max(mw, f.getStringWidth(s));
        w = mw + 14;
        h = ls.size() * 11 + 5;
        bg(w, h);
        int yy = y + 4;
        for (String s : ls) {
            f.drawStringWithShadow(s, x + 9, yy, 0xFFFFFFFF);
            yy += 11;
        }
    }
}

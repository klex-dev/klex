package dev.klex.core;

import net.minecraft.client.Minecraft;
import net.minecraftforge.client.event.ClientChatReceivedEvent;
import net.minecraftforge.client.event.FOVUpdateEvent;
import net.minecraftforge.client.event.RenderBlockOverlayEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent;

import java.util.ArrayList;
import java.util.List;

public class Module {
    public final String name, desc;
    public final Category cat;
    public boolean enabled;
    public float anim;
    public final List<Setting> settings = new ArrayList<>();
    protected final Minecraft mc = Minecraft.getMinecraft();

    public Module(String name, String desc, Category cat) {
        this.name = name; this.desc = desc; this.cat = cat;
    }

    public void toggle() { setEnabled(!enabled); }

    public void setEnabled(boolean b) {
        if (enabled == b) return;
        enabled = b;
        if (b) onEnable(); else onDisable();
    }

    protected Setting add(Setting s) { settings.add(s); return s; }

    public boolean bool(String n) {
        for (Setting s : settings) if (s.name.equals(n)) return s.b;
        return false;
    }

    public double num(String n) {
        for (Setting s : settings) if (s.name.equals(n)) return s.v;
        return 0;
    }

    public void onEnable() {}
    public void onDisable() {}
    public void onTick() {}
    public void onOverlayPre(RenderGameOverlayEvent.Pre e) {}
    public void onFov(FOVUpdateEvent e) {}
    public void onChat(ClientChatReceivedEvent e) {}
    public void onBlockOverlay(RenderBlockOverlayEvent e) {}
}

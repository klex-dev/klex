package dev.klex.core;

import net.minecraft.client.Minecraft;
import net.minecraft.client.entity.EntityPlayerSP;

import java.util.ArrayList;
import java.util.List;

public class Stats {
    public static int combo;
    public static double speed;
    private static double lx, lz;
    private static float lastHealth = -1f;
    private static final List<Long> L = new ArrayList<>(), R = new ArrayList<>();

    public static void click(int b) { (b == 0 ? L : R).add(System.currentTimeMillis()); }

    public static int cps(int b) {
        final long n = System.currentTimeMillis();
        List<Long> l = b == 0 ? L : R;
        l.removeIf(t -> n - t > 1000);
        return l.size();
    }

    public static void tick() {
        EntityPlayerSP p = Minecraft.getMinecraft().thePlayer;
        double dx = p.posX - lx, dz = p.posZ - lz;
        speed = Math.sqrt(dx * dx + dz * dz) * 20.0;
        lx = p.posX; lz = p.posZ;
        if (lastHealth >= 0f && p.getHealth() < lastHealth) combo = 0;
        lastHealth = p.getHealth();
    }
}

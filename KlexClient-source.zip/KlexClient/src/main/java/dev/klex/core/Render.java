package dev.klex.core;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.FontRenderer;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.WorldRenderer;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;

public class Render {
    public static final int A1 = 0xFF8B5CF6; // violet
    public static final int A2 = 0xFFEC4899; // pink

    public static void rect(int x, int y, int w, int h, int c) { Gui.drawRect(x, y, x + w, y + h, c); }

    public static void rrect(int x, int y, int w, int h, int r, int c) {
        r = Math.min(r, Math.min(w, h) / 2);
        if (r <= 0) { rect(x, y, w, h, c); return; }
        Gui.drawRect(x, y + r, x + w, y + h - r, c);
        for (int i = 0; i < r; i++) {
            double d = r - i - 0.5;
            int inset = (int) Math.round(r - Math.sqrt(r * r - d * d));
            Gui.drawRect(x + inset, y + i, x + w - inset, y + i + 1, c);
            Gui.drawRect(x + inset, y + h - i - 1, x + w - inset, y + h - i, c);
        }
    }

    public static void outline(int x, int y, int w, int h, int c) {
        rect(x, y, w, 1, c); rect(x, y + h - 1, w, 1, c);
        rect(x, y, 1, h, c); rect(x + w - 1, y, 1, h, c);
    }

    public static int lerp(int a, int b, float t) {
        t = Math.max(0f, Math.min(1f, t));
        int r = 0;
        for (int s = 24; s >= 0; s -= 8) {
            int ca = (a >> s) & 255, cb = (b >> s) & 255;
            r |= ((int) (ca + (cb - ca) * t)) << s;
        }
        return r;
    }

    public static void gradH(int x, int y, int w, int h, int c1, int c2) {
        float a1 = (c1 >> 24 & 255) / 255f, r1 = (c1 >> 16 & 255) / 255f, g1 = (c1 >> 8 & 255) / 255f, b1 = (c1 & 255) / 255f;
        float a2 = (c2 >> 24 & 255) / 255f, r2 = (c2 >> 16 & 255) / 255f, g2 = (c2 >> 8 & 255) / 255f, b2 = (c2 & 255) / 255f;
        GlStateManager.disableTexture2D();
        GlStateManager.enableBlend();
        GlStateManager.disableAlpha();
        GlStateManager.tryBlendFuncSeparate(770, 771, 1, 0);
        GlStateManager.shadeModel(7425);
        Tessellator t = Tessellator.getInstance();
        WorldRenderer wr = t.getWorldRenderer();
        wr.begin(7, DefaultVertexFormats.POSITION_COLOR);
        wr.pos(x + w, y, 0).color(r2, g2, b2, a2).endVertex();
        wr.pos(x, y, 0).color(r1, g1, b1, a1).endVertex();
        wr.pos(x, y + h, 0).color(r1, g1, b1, a1).endVertex();
        wr.pos(x + w, y + h, 0).color(r2, g2, b2, a2).endVertex();
        t.draw();
        GlStateManager.shadeModel(7424);
        GlStateManager.disableBlend();
        GlStateManager.enableAlpha();
        GlStateManager.enableTexture2D();
    }

    public static void gradText(String s, float x, float y, float sc) {
        FontRenderer f = Minecraft.getMinecraft().fontRendererObj;
        GlStateManager.pushMatrix();
        GlStateManager.scale(sc, sc, 1f);
        float cx = x / sc, cy = y / sc;
        int n = s.length();
        for (int i = 0; i < n; i++) {
            String c = String.valueOf(s.charAt(i));
            f.drawStringWithShadow(c, cx, cy, lerp(A1, A2, i / (float) Math.max(1, n - 1)));
            cx += f.getStringWidth(c);
        }
        GlStateManager.popMatrix();
    }

    public static void toggle(int x, int y, float anim) {
        rrect(x, y, 24, 12, 6, lerp(0xFF2A2A38, A1, anim));
        rrect(x + 2 + (int) (12 * anim), y + 2, 8, 8, 4, 0xFFFFFFFF);
    }
}

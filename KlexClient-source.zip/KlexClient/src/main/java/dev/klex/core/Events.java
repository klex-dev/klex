package dev.klex.core;

import dev.klex.gui.ClickGui;
import dev.klex.gui.HudEditor;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraftforge.client.event.ClientChatReceivedEvent;
import net.minecraftforge.client.event.FOVUpdateEvent;
import net.minecraftforge.client.event.MouseEvent;
import net.minecraftforge.client.event.RenderBlockOverlayEvent;
import net.minecraftforge.client.event.RenderGameOverlayEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.InputEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

public class Events {
    private final Minecraft mc = Minecraft.getMinecraft();

    @SubscribeEvent
    public void tick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END || mc.thePlayer == null || mc.theWorld == null) return;
        Stats.tick();
        for (Module m : ModuleManager.all) if (m.enabled) m.onTick();
    }

    @SubscribeEvent
    public void key(InputEvent.KeyInputEvent e) {
        if (Keyboard.getEventKeyState() && Keyboard.getEventKey() == Keyboard.KEY_RSHIFT && mc.currentScreen == null)
            mc.displayGuiScreen(new ClickGui());
    }

    @SubscribeEvent
    public void pre(RenderGameOverlayEvent.Pre e) {
        for (Module m : ModuleManager.all) if (m.enabled) m.onOverlayPre(e);
    }

    @SubscribeEvent
    public void post(RenderGameOverlayEvent.Post e) {
        if (e.type != RenderGameOverlayEvent.ElementType.ALL) return;
        if (mc.thePlayer == null || mc.theWorld == null || mc.gameSettings.showDebugInfo || mc.currentScreen instanceof HudEditor) return;
        ScaledResolution sr = new ScaledResolution(mc);
        for (Module m : ModuleManager.all)
            if (m.enabled && m instanceof HudModule) ((HudModule) m).draw(sr, false);
    }

    @SubscribeEvent
    public void fov(FOVUpdateEvent e) {
        for (Module m : ModuleManager.all) if (m.enabled) m.onFov(e);
    }

    @SubscribeEvent
    public void chat(ClientChatReceivedEvent e) {
        for (Module m : ModuleManager.all) if (m.enabled) m.onChat(e);
    }

    @SubscribeEvent
    public void overlay(RenderBlockOverlayEvent e) {
        for (Module m : ModuleManager.all) if (m.enabled) m.onBlockOverlay(e);
    }

    @SubscribeEvent
    public void mouse(MouseEvent e) {
        if (e.buttonstate && (e.button == 0 || e.button == 1)) Stats.click(e.button);
    }

    @SubscribeEvent
    public void attack(AttackEntityEvent e) {
        if (e.entityPlayer == mc.thePlayer) Stats.combo++;
    }
}
